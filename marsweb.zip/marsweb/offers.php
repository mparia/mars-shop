<?php 
    include('./config/database_connect.php');

    $sql2 = 'SELECT * FROM marsoffer';
    $result2 = mysqli_query($conn,$sql2);
    $marsoffer = mysqli_fetch_all($result2 , MYSQLI_ASSOC);
    mysqli_free_result($result2);
    mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">
    <?php include('header.php')?>
    <div class="off-main">
        <div class="off-container">
            <?php foreach($marsoffer as $marsoffercollection){?>
            <div class="off-title">
                 <?php echo $marsoffercollection['title'] ?>
            </div>
            <div class="off-image">
                <img src="./pics/t.1.1.jpg" alt="t.1.1">
                <img src="./pics/t.1.2.jpg" alt="t.1.2">
                <img src="./pics/t.1.3.jpg" alt="t.1.3">
                <img src="./pics/t.1.4.jpg" alt="t.1.4">
            </div>
            <div class="off-cost">تومان
                <?php echo $marsoffercollection['cost'] ?>
            </div>
            <div class="off-new-cost">تومان
                <?php echo $marsoffercollection['newcost'] ?>
            </div>
            <?php } ?>

            <div class="return-button">
                <a href="index.php">بازگشت</a>
            </div>
            
        </div>    

    </div>
        
    <?php include('footer.php') ?>
</html>