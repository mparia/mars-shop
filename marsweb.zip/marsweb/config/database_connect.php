<?php

    //connect database to my code
    //$conn = mysqli_connect("host type" , "host account" , "host pass" , "table name")
    $conn = mysqli_connect("localhost","root",null,"marsweb");

    if(!$conn){
        echo"connection Error ".mysqli_connect_error();
    }
?>
