<footer>
    <p class="foot">copyright 2023 MarsWeb</p>
</footer>

</body>

