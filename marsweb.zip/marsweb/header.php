<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mars Web</title>
    <script src="https://kit.fontawesome.com/5dd6c7af4c.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="loginStyle.css">  
    <link rel="stylesheet" href="detailStyle.css">
    <link rel="stylesheet" href="offersStyle.css">
</head>
<body>
    <header>
            <div class="right-container">
                <div class="buttons">
                    <div class="home-button">
                        <a href="index.php">خانه <i class="fa-solid fa-house"></i></a>
                    </div>
                    <div class="login-button">
                        <a href="login.php">ورود<i class="fa-solid fa-user-tie"></i></a>
                    </div>
                    <div class="about-button">
                        <a href="index.php#about-us">درباره ما<i class="fa-solid fa-info"></i></a>
                    </div>

                </div>
            </div>
            <div class="left-container">
                <a class= "logo" href = "index.php"><i class="fa-solid fa-mars"></i>Mars Shop</a>

            </div>
    </header>

    <main>

    </main>
    