<!--PHP Part-->

<?php

    include("./config/database_connect.php");



    $id = $email = $password = '';

    //Sakhte yek array baraye error ha dar safhe login

    $errors = array('id'=> '' , 'mail' => '' , 'pass' => '');
    if(isset($_POST['submit'])){
        $id =$_POST['id'];
        $email = $_POST['mail'];
        $password = $_POST['pass'];
        
        
            //check kardane khali nabudane 'ID' ba 'empty' function
                if(empty($_POST['id'])){
                    $errors['id'] = 'وارد کردن شناسه کاربری الزامی است'; 
                }
            
            //check kardane valid boodane 'ID' be komake function 'preg_match'   va regular expression *site REGEXR.COM*
            //if paiin yaani agar function preg_match false bood(!) yaani shart haye dakhele parantez bargharar nabood error bede
                else{
                    if(!preg_match('/[a-zA-Z0-9]{4,100}/', $_POST['id'])){
                        $errors['id'] = 'شناسه کاربری باید حداقل شامل 4 کاراکتر باشد';
                        }
                    }


                if(empty($_POST['mail'])){
                    $errors['mail'] = 'وارد کردن ایمیل الزامی است'; 

                }
                else{
                           /*sehat sanji dorost boodane email ba php*/ 
                        if(!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)){ 
                           $errors['mail'] = 'ایمیل نامعتبر است';
                       }
                    }

                
                if(empty($_POST['pass'])){
                    $errors['pass'] = 'وارد کردن گذرواژه الزامی است';

                }
                else{
                    if(!preg_match('/[a-zA-Z0-9]{6,16}/', $_POST['pass'])){
                        $errors['pass'] = 'گذرواژه باید حداقل 6 و حداکثر 16 کاراکتر داشته باشد';
                        }
                    }

                //check kardane inke agar array 'erroe' khali bood yaani erorri vojood nadasht, safhe index.php ro baz kon 
                if(!array_filter($errors)){
                    $id = mysqli_real_escape_string($conn, $_POST['id']);
                    $email = mysqli_real_escape_string($conn, $_POST['mail']);
                    $password = mysqli_real_escape_string($conn, $_POST['pass']);
 
                    //redirect to index.php 
                    header('location: index.php');
                }

    }
?>



<!--HTML Part-->

<!DOCTYPE html>
<html lang="en">

    <?php include('header.php')?>

        <div class="login">
            <div class="form-name">
                <p>فرم ورود</p>
            </div>
            <br>
            <div class="login-form">

            <!--ersale info be server ba raveshe POST-->
                <form id="form1" action="login.php" method="POST">
                    
                    <label for="id">
                    <i class="fa-solid fa-user"></i>
                        شناسه کاربری</label>

                    <!--baraye 'value' be in elat value set kardam ke form ba error ha napare har chi por karde taraf-->

                    <input type="text" id="id" name = "id" value="<?php echo $id; ?>">  
                    <p class="require"><?php echo $errors['id']; ?></p>    
                    <br>
                    
                    <label for="mail">
                    <i class="fa-solid fa-envelope"></i>
                        ایمیل</label>
                    <input type="email" id="mail" name = "mail" value = "<?php echo $email; ?>">
                    <p class="require"><?php echo $errors['mail']; ?></p>
                    <br>

                    <label for="pass">
                    <i class="fa-solid fa-key"></i>    
                    رمز عبور</label>
                    <input type="password" id="pass" name = "pass" value="<?php echo $password; ?>">
                    <p class="require"><?php echo $errors['pass']; ?></p>
                    <br>

                                
                </form>

                <button type="submit" name="submit" form="form1" value="submit">ثبت</button>
            </div>
        </div>

    <?php include('footer.php')?>


</html>