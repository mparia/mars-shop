<?php
     include("config/database_connect.php");

     

     if(isset($_GET['marsid'])){
        $id = mysqli_real_escape_string($conn, $_GET['marsid']);
        $sql3 = "SELECT * FROM mars WHERE marsid = $id";
        $resault = mysqli_query($conn, $sql3);
        $mymars = mysqli_fetch_assoc($resault);
 
     mysqli_free_result($resault);
     mysqli_close($conn);

     //print_r($mars);
    }
 
 

?>

<!DOCTYPE html>
<html lang="en">
    <?php include('header.php') ?>
    <div class="de-container">
      <?php if($mymars) { ?>
      <div class="de-title">
         <p><?php echo $mymars['title']; ?></p>
      </div>
      <?php } ?>
      <div class="de-images">
        <?php if($mymars['marsid'] == 1) { ?>
        <div class="image-top">
          <img src="./pics/l.1.1.jpg" alt="1.1">
          <img src="./pics/l.1.2.jpg" alt="1.2">
        </div>
        <div class="image-bot">
        <img src="./pics/l.1.3.jpg" alt="1.3">
        <img src="./pics/l.1.4.jpg" alt="1.4">
        </div>
        <?php } ?>
        <?php if($mymars['marsid'] == 2) { ?>
        <div class="image-top">
          <img src="./pics/s.1.1.jpg" alt="1.1">
          <img src="./pics/s.1.2.jpg" alt="1.2">
        </div>
        <div class="image-bot">
        <img src="./pics/s.1.3.jpg" alt="1.3">
        <img src="./pics/s.1.4.jpg" alt="1.4">
        </div>
        <?php } ?>
        <?php if($mymars['marsid'] == 3) { ?>
        <div class="image-top">
          <img src="./pics/ki.1.1.jpg" alt="1.1">
          <img src="./pics/ki.1.2.jpg" alt="1.2">
        </div>
        <div class="image-bot">
        <img src="./pics/ki.1.3.jpg" alt="1.3">
        <img src="./pics/ki.1.4.jpg" alt="1.4">
        </div>
        <?php } ?>
        <?php if($mymars['marsid'] == 4) { ?>
        <div class="image-top">
          <img src="./pics/ka.1.1.jpg" alt="1.1">
          <img src="./pics/ka.1.2.jpg" alt="1.2">
        </div>
        <div class="image-bot">
        <img src="./pics/ka.1.3.jpg" alt="1.3">
        <img src="./pics/ka.1.4.jpg" alt="1.4">
        </div>
        <?php } ?>
      </div>
         

      <div class="de-detail">

      </div>

    </div>
     
     
     


    <?php include('./footer.php'); ?>
</html>