<?php 
    include("config/database_connect.php");


    //MAIN PART

    //ijade query
    //select hame chi az marsweb
    //$sql => querye
    $sql = 'SELECT * FROM mars';

    //sakhte query
    $resault = mysqli_query($conn, $sql);

    //daryafte etelaat
    //daryafte etelaat besoorate associative array
    $mars = mysqli_fetch_all($resault , MYSQLI_ASSOC);

    //khali kardane resault
    mysqli_free_result($resault);
    //ghaat kardane connection

    //OFFER PART
    $sql1 = 'SELECT * FROM marsoffer';

    $resault1 = mysqli_query($conn, $sql1);
    $marsoffer = mysqli_fetch_all($resault1 , MYSQLI_ASSOC);
    mysqli_free_result($resault1);

    //DETAIL PART
    if(isset($_GET['marsid'])){
        $id = mysqli_real_escape_string($conn, $_GET['marsid']);
        $sql3 = "SELECT * FROM mars WHERE marsid = $id";
        $resault3 = mysqli_query($conn, $sql3);
        $mymars = mysqli_fetch_assoc($resault3);
        mysqli_free_result($resault3);
        $photoAdd = "./pics/".$id.".jpg";
    }

    //CONTACT PART

    $sql2 = 'SELECT * FROM marscontact';

    $resault2 = mysqli_query($conn, $sql2);
    $marscontact = mysqli_fetch_all($resault2 , MYSQLI_ASSOC);
    mysqli_free_result($resault2);



    //ghaat kardane connection
    mysqli_close($conn);


?>
<!DOCTYPE html>
<html lang="en">

    <?php 
        include("header.php");?>

        <div class="main-page">

            <div class="offer">
                <div class="offer-title">
                    <p>داغ ترین ها</p>
                </div>
                <a class="offer-link" href="offers.php">
                    <div class="offer-photo">
                        <img src="./pics/dors.jpg" alt="Tshirt-offer">
                        <?php foreach($marsoffer as $marscollectionoffer) {?>
                        <div class="offer-detail">
                            <p class="photo-title"><?php echo $marscollectionoffer['ingredients']; ?></p>
                        </div>
                        <?php } ?>
                    </div>
                    
                </a>
            </div>

            <div class="container">
                <div class="container-title">دسته بندی ها</div>
                <div class="container-cateqory">
                <?php foreach($mars as $marscollection) { ?>
                    <div class="collection-cat">
                        <div class="collection-photo">
                            <?php if($marscollection['marsid'] == 1){ ?>
                            <a href="details.php?marsid=<?php echo $marscollection['marsid'] ?>"><img src="./pics/lebas.jpg" alt="labas"></a>
                            <?php } ?>
                            <?php if($marscollection['marsid'] == 2){ ?>
                            <a href="details.php?marsid=<?php echo $marscollection['marsid'] ?>"><img src="./pics/shalvar.jpg" alt="shalvar"></a>
                            <?php } ?>
                            <?php if($marscollection['marsid'] == 3){ ?>
                            <a href="details.php?marsid=<?php echo $marscollection['marsid'] ?>"><img src="./pics/kif.jpg" alt="kif"></a>
                            <?php } ?>
                            <?php if($marscollection['marsid'] == 4){ ?>
                            <a href="details.php?marsid=<?php echo $marscollection['marsid'] ?>"><img src="./pics/kafsh.jpg" alt="kafsh"></a>
                            <?php } ?>
                        </div>
                        <div class="collection-title">
                            <?php echo $marscollection['title'];?>
                        </div>
                        <div class="collection-detail">
                            <p class="detail-title"><?php echo $marscollection['ingredients']; ?></p>
                            <a class="more-info" href="details.php?marsid=<?php echo $marscollection['marsid'] ?>">اطلاعات بیشتر</a>
                        </div>
                    </div>
                <?php } ?>
                            
            </div>

            <div id="about-us" class="contact">
                <div class="contact-title">ارتباط با ما</div>
            <?php foreach($marscontact as $marscollectioncontact) {?>
                <div class="contact-info">
                    <?php echo $marscollectioncontact['title'].' : ';
                    echo $marscollectioncontact['ingredients']; ?>
                </div>
            <?php } ?>

            </div>


        </div>
        
    
    <?php
        include("footer.php");
    ?>

</html>