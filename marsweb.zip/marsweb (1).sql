-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2024 at 08:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `marsweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `mars`
--

CREATE TABLE `mars` (
  `marsid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `ingredients` varchar(255) NOT NULL,
  `cost` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mars`
--

INSERT INTO `mars` (`marsid`, `title`, `ingredients`, `cost`, `created_at`) VALUES
(1, 'لباس', 'هودی، دورس، تیشرت ', 200000, '2023-11-12 20:14:35'),
(2, 'شلوار', 'کارگو، جاگر، مام استایل\r\n', 800000, '2023-11-12 20:12:18'),
(3, 'کیف', 'کوله، بادی بگ', 550000, '2023-11-12 20:47:34'),
(4, 'کفش', 'آل استار، ونس', 150000, '2023-11-12 20:47:50');

-- --------------------------------------------------------

--
-- Table structure for table `marscontact`
--

CREATE TABLE `marscontact` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `ingredients` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marscontact`
--

INSERT INTO `marscontact` (`id`, `title`, `ingredients`) VALUES
(1, 'Instagram', '@Mars_Web_Shop'),
(2, 'Whatsapp', '09155161516');

-- --------------------------------------------------------

--
-- Table structure for table `marsoffer`
--

CREATE TABLE `marsoffer` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `ingredients` varchar(255) NOT NULL,
  `cost` int(11) NOT NULL,
  `newcost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marsoffer`
--

INSERT INTO `marsoffer` (`id`, `title`, `ingredients`, `cost`, `newcost`) VALUES
(1, 'تخفیف تیشرت', 'تخفیف 20 درصدی تمامی تیشرت ها', 150000, 120000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mars`
--
ALTER TABLE `mars`
  ADD PRIMARY KEY (`marsid`);

--
-- Indexes for table `marscontact`
--
ALTER TABLE `marscontact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marsoffer`
--
ALTER TABLE `marsoffer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mars`
--
ALTER TABLE `mars`
  MODIFY `marsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `marscontact`
--
ALTER TABLE `marscontact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `marsoffer`
--
ALTER TABLE `marsoffer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
